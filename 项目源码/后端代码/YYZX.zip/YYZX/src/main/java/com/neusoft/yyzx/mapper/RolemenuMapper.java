package com.neusoft.yyzx.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.neusoft.yyzx.pojo.Rolemenu;

public interface RolemenuMapper extends BaseMapper<Rolemenu> {
}
