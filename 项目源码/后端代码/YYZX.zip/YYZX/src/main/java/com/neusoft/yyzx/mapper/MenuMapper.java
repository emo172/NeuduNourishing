package com.neusoft.yyzx.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.neusoft.yyzx.pojo.Menu;

public interface MenuMapper extends BaseMapper<Menu> {
}
