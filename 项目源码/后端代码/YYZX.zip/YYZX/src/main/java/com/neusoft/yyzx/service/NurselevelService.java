package com.neusoft.yyzx.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.neusoft.yyzx.pojo.Nurselevel;

public interface NurselevelService extends IService<Nurselevel> {
}
