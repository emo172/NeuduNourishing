package com.neusoft.yyzx.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.neusoft.yyzx.pojo.Room;

public interface RoomMapper extends BaseMapper<Room> {
}
