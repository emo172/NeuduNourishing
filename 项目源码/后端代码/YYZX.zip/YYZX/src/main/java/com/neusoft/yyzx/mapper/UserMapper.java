package com.neusoft.yyzx.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.mapper.Mapper;
import com.neusoft.yyzx.pojo.User;

public interface UserMapper extends Mapper<User>, BaseMapper<User> {
}
