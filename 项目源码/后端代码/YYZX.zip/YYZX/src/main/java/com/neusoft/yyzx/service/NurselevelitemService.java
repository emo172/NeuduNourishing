package com.neusoft.yyzx.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.neusoft.yyzx.pojo.Nurselevelitem;

public interface NurselevelitemService extends IService<Nurselevelitem> {
}
