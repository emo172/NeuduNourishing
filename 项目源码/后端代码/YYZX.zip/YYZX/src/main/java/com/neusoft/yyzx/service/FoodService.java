package com.neusoft.yyzx.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.neusoft.yyzx.pojo.Food;

public interface FoodService extends IService<Food> {
}
