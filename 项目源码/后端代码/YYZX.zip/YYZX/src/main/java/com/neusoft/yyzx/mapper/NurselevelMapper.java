package com.neusoft.yyzx.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.neusoft.yyzx.pojo.Nurselevel;

public interface NurselevelMapper extends BaseMapper<Nurselevel> {
}
