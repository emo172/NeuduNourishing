package com.neusoft.yyzx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YyzxApplicationTests {

    @Test
    void contextLoads() {
    }

}
