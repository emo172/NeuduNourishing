<template>
	<div>

	</div>
</template>

<script>
	export default {

	}
</script>

<style scope>
	div {
		width: 100%;
		height: 100%;
		background: url('@/assets/404.png') no-repeat center;
	}
</style>